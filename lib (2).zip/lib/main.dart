import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math';

// Card Model
class PokemonCard {
  final String id;
  final String name;
  final String imageUrl;
  final int hp;

  PokemonCard({required this.id, required this.name, required this.imageUrl, required this.hp});

  factory PokemonCard.fromJson(Map<String, dynamic> json) {
    return PokemonCard(
      id: json['id'],
      name: json['name'],
      imageUrl: json['images']['small'],
      hp: int.tryParse(json['hp'] ?? '0') ?? 0, // Default HP to 0 if unavailable
    );
  }
}

// API Service to fetch cards
class ApiService {
  Future<List<PokemonCard>> fetchAllCards() async {
    final List<PokemonCard> cards = [];
    final response = await http.get(Uri.parse('https://api.pokemontcg.io/v2/cards?page=1&pageSize=100'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final cardsList = data['data'];
      for (var cardJson in cardsList) {
        cards.add(PokemonCard.fromJson(cardJson));
      }
    } else {
      throw Exception('Failed to load cards');
    }
    return cards;
  }
}

// Splash Screen Widget
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => PokemonBattleGame()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/ok.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            // Background image
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/ok.jpeg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            // Logo in front of the background
            Center(
              child: Image.asset(
                'assets/Pokemon.png',
                fit: BoxFit.contain,
                width: MediaQuery.of(context).size.width * 0.8, // Increased logo size
                height: MediaQuery.of(context).size.height * 0.5, // Increased logo size
              ),
            ),
            // Loading indicator
            Positioned(
              bottom: 50,
              left: MediaQuery.of(context).size.width * 0.5 - 25, // Center the loading spinner
              child: const CircularProgressIndicator(color: Color.fromARGB(255, 187, 208, 0)),
            ),
          ],
        ),
      ),
    );
  }
}

// Main Game Screen
class PokemonBattleGame extends StatefulWidget {
  @override
  _PokemonBattleGameState createState() => _PokemonBattleGameState();
}

class _PokemonBattleGameState extends State<PokemonBattleGame> with SingleTickerProviderStateMixin {
  late Future<List<PokemonCard>> futureCards;
  PokemonCard? card1;
  PokemonCard? card2;
  String? winnerMessage;

  late AnimationController animationController;
  late Animation<double> scaleAnimation;

  @override
  void initState() {
    super.initState();
    futureCards = ApiService().fetchAllCards();

    animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: animationController, curve: Curves.elasticOut),
    );
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  void pickRandomCards(List<PokemonCard> cards) {
    final random = Random();
    setState(() {
      card1 = cards[random.nextInt(cards.length)];
      card2 = cards[random.nextInt(cards.length)];
      determineWinner();
    });
    animationController.forward(from: 0.0);
  }

  void determineWinner() {
    if (card1 != null && card2 != null) {
      if (card1!.hp > card2!.hp) {
        winnerMessage = '${card1!.name} wins with ${card1!.hp} HP!';
      } else if (card1!.hp < card2!.hp) {
        winnerMessage = '${card2!.name} wins with ${card2!.hp} HP!';
      } else {
        winnerMessage = 'It\'s a draw! Both have ${card1!.hp} HP!';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0, // Removes the shadow from the app bar for a seamless look
        backgroundColor: Colors.transparent, // Makes the app bar background transparent
        flexibleSpace: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/ok.jpeg'), // Background image for the app bar
              fit: BoxFit.cover, // Adjusts the image to cover the app bar
            ),
          ),
          child: Align(
            alignment: Alignment.center,
            child: Image.asset(
              'assets/Pokemon.png', // Your logo image
              height: 600, // Adjust the size of the logo as needed
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Game Info'),
                  content: const Text(
                      'Welcome to the Pokemon Battle Game! Tap "Play Again" to randomly pick two Pokémon and determine the winner based on their HP.'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/ok.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child: FutureBuilder<List<PokemonCard>>(
          future: futureCards,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No cards available.'));
            } else {
              final cards = snapshot.data!;
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (card1 != null && card2 != null)
                      ScaleTransition(
                        scale: scaleAnimation,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Adjust card size based on screen width
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.35,
                              child: CardWidget(card: card1!),
                            ),
                            const SizedBox(width: 20),
                            const Text(
                              'VS',
                              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 247, 6, 6)),
                            ),
                            const SizedBox(width: 20),
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.35,
                              child: CardWidget(card: card2!),
                            ),
                          ],
                        ),
                      ),
                    if (card1 != null && card2 != null) const SizedBox(height: 20),
                    if (winnerMessage != null)
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Text(
                          winnerMessage!,
                          style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 0, 255, 13)),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () => pickRandomCards(cards),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 25),
                        backgroundColor: const Color.fromARGB(255, 208, 214, 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                        textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      child: Text(card1 == null ? 'Start Game' : 'Play Again'),
                    ),
                  ],
                ),
              );
            }
          },
        ),
      ),
    );
  }
}

// Card Display Widget
class CardWidget extends StatelessWidget {
  final PokemonCard card;

  const CardWidget({Key? key, required this.card}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 5,
      child: Column(
        children: [
          CachedNetworkImage(
            imageUrl: card.imageUrl,
            placeholder: (context, url) => const CircularProgressIndicator(),
            errorWidget: (context, url, error) => const Icon(Icons.error),
            height: 200, // Reduced height for cards
            width: double.infinity, // Make the width flexible
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 10),
          Text(
            card.name,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Text(
            'HP: ${card.hp}',
            style: const TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SplashScreen(),
  ));
}
